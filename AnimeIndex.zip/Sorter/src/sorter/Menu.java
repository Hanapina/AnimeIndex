/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorter;

import java.io.IOException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Jesse
 */

/** This menu is used for handling the menu and using MenuFunctions for their 
 *  needs.
 */
public class Menu implements MenuFunctions{
    
    @Override
    public void intro() {
        System.out.println("Welcome to The Weeb Index.");
        System.out.println("What do you want to do today?");
        System.out.println("1. Add an entry.\n2. Display current file list."
                + "\n3. Sort your text file."
                + "\n4. Exit\n");
    }

    @Override
    public void menu() {
        boolean token = true;
        String fileName = "anime_index.txt";
        // Token is used to check for overall input validity.  
        while (token) {
            try {
                String choiceNum;
                int actualNum = -1;
                boolean inputCheck = false;
                
                // Checks for input being an integer.
                intro();
                System.out.println("Your current file that you are working"
                            + " with is: " + fileName + "\n");
                while (!inputCheck) {
                    System.out.println("Please enter a number of choice.");
                    Scanner userInput = new Scanner(System.in);
                    choiceNum = userInput.next();
                    try {
                        actualNum = Integer.parseInt(choiceNum);
                        inputCheck = true;
                    } catch(NumberFormatException e){
                        System.out.println("Error: Input is not of number value."
                                + " Please enter a number of choice.");
                    }
                }
                
                switch (actualNum) {
                    case 1:
                        //Add_list
                        MenuFunctions.add_list(fileName);
                        break;
                    case 2:
                        MenuFunctions.display_list(fileName);
                        break;
                    case 3:
                        String userInput;
                        int input = -1;
                        boolean stringCheck = false;
                        boolean numberCheck = false;
                        System.out.println("Please choose what you want to"
                                + " sort by. Input the number.\n"
                                + "1 for names\n"
                                + "2 for seasons\n"
                                + "3 for years.");
                        while (!stringCheck || !numberCheck) {
                            Scanner sortInput = new Scanner(System.in);
                            userInput = sortInput.next();
                            try {
                                input = Integer.parseInt(userInput);
                                stringCheck = true;
                            } catch(NumberFormatException e){
                                System.out.println("Error: Input is not of number value."
                                        + " Please enter a number of choice.");
                            }
                            if (input != 1 && input != 2 && input != 3) {
                                System.out.println("Error: Please only input 1, 2"
                                        + " or 3.");
                            } else {
                                numberCheck = true;
                            }
                        }
                        MenuFunctions.sort_functions(fileName, input);
                    /*
                    case 4:
                        break;
                    case 5:
                        System.out.println("Currently not implemented\n");
                        break;
                    */
                    case 4:
                        token = false;
                        System.out.println("Exiting.");
                        break;
                    default:
                        System.out.println("Error: Invalid input. You entered a number"
                                + " that was not listed.\n");
                } 
            } catch (IOException ex) {
                Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
